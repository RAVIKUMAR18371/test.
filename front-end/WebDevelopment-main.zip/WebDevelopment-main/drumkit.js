alert("w drum");
alert("a drum");
alert("s drum");
alert("d drum");
alert("j drum");
alert("k drum");
alert("l drum");